// UniSphere — lightweight client-side interactions

const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

menuToggle.addEventListener("click", () => {
  const opened = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(opened));
});

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

// Event filtering
const filterButtons = document.querySelectorAll(".filter");
const eventCards = document.querySelectorAll(".event-card");

filterButtons.forEach(button => {
  button.addEventListener("click", () => {
    filterButtons.forEach(item => item.classList.remove("active"));
    button.classList.add("active");

    const filter = button.dataset.filter;

    eventCards.forEach(card => {
      const show = filter === "all" || card.dataset.category === filter;
      card.style.display = show ? "" : "none";
    });
  });
});

// Register buttons automatically select the chosen event
document.querySelectorAll(".register-event").forEach(button => {
  button.addEventListener("click", () => {
    const eventName = button.dataset.event;
    document.querySelector("#eventSelect").value = eventName;
    document.querySelector("#registration").scrollIntoView({ behavior: "smooth" });
    document.querySelector("#studentName").focus();
  });
});

// Form validation + confirmation message
const form = document.querySelector("#eventForm");
const message = document.querySelector("#formMessage");

form.addEventListener("submit", (event) => {
  event.preventDefault();

  const name = document.querySelector("#studentName").value.trim();
  const selectedEvent = document.querySelector("#eventSelect").value;

  if (!name || !selectedEvent) {
    message.textContent = "Please complete all required fields.";
    message.style.color = "#fda4af";
    return;
  }

  message.textContent = `Registration successful, ${name}! Your spot for ${selectedEvent} is reserved.`;
  message.style.color = "#86efac";
  form.reset();
});

// Add active navigation state while scrolling
const sections = document.querySelectorAll("main section[id]");
const navAnchors = document.querySelectorAll(".nav-links a");

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      navAnchors.forEach(anchor => {
        anchor.classList.toggle(
          "active",
          anchor.getAttribute("href") === `#${entry.target.id}`
        );
      });
    }
  });
}, { rootMargin: "-35% 0px -55% 0px" });

sections.forEach(section => observer.observe(section));
