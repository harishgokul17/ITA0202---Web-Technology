# UniSphere — Responsive University Event Registration Portal

## Files
- `index.html` — semantic webpage structure
- `style.css` — main external CSS
- `script.js` — filtering, mobile menu and form interaction

## How to run
Open `index.html` directly in Firefox/Chromium, or use Live Server.

## CSS assessment coverage
- Inline CSS: small `INLINE CSS` label.
- Internal CSS: `#assessment-note` section in `index.html`.
- External CSS: `style.css` contains the main website design.
- Selectors: element, class, ID, grouped/descendant, child-related selectors, attribute, pseudo-class and pseudo-element selectors are demonstrated.
- Box model: event cards use margin, padding, border and content sizing.
- Primary layout: CSS Grid for event cards and Flexbox for navigation/components.
- Beyond normal flow: sticky header, fixed help button, absolute hero/orbit elements, z-index.
- Visual properties: gradients, border-radius, box-shadow, opacity, overflow, cursor, transition, transform, max-width and more.
- Responsive design: media queries at 980px, 680px and 375px.
- Functional interactions: event filters, register buttons, responsive menu and client-side registration confirmation.

## Box-model calculation
For the demonstrated event-card example under `content-box`:
320px content + 20px left/right padding + 1px left/right border = 362px total horizontal width.

Note: the CSS globally uses `box-sizing: border-box` for predictable layout. For the assessment's default `content-box` calculation, the dimensions above are demonstrated conceptually; inspect the card in Developer Tools and temporarily set `box-sizing: content-box` if you need to capture the exact default-model screenshot.
